<?php
if (isset($_SESSION['user_id'])) {
    echo $_SESSION['user_id'];
} else {
    echo 'Not logged in';
}
?>