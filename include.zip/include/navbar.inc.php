<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container bg-dark bg-gradient">
        <a class="navbar-brand" href="<?php echo $baseUrl ?>?page=dashboard">Navbar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <!-- <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>-->
                <li class="nav-item">
                    <?php if ($isAdmin) { ?>
                        <a class="nav-link" href="<?php echo $baseUrl ?>?page=user/list">User</a>
                    <?php } ?>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Auth
                    </a>
                    <ul class="dropdown-menu">
                        <?php if (empty($user)) { ?>
                            <li><a class="dropdown-item" href="<?php echo $baseUrl ?>?page=login">Login</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="<?php echo $baseUrl ?>?page=register">Register</a></li>
                        <?php } else { ?>
                            <li><a class="dropdown-item" href="<?php echo $baseUrl ?>?page=logout">Logout</a></li>
                            <li><a class="dropdown-item" href="<?php echo $baseUrl ?>?page=profile">Profile</a></li>
                        <?php } ?>
                    </ul>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link disabled" aria-disabled="true">Disabled</a>
                </li> -->
            </ul>
            <!-- <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form> -->
        </div>
    </div>
</nav>